<?php
namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MobileInResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'=>$this->id,
            'user'=> new UserBasicResource($this->whenLoaded('user')),
            'store'=> new StoreResource($this->whenLoaded('store')),
            'device'=> new DeviceResource($this->whenLoaded('device')),
            'color'=> new ColorResource($this->whenLoaded('color')),
            'storage'=> new DeviceStorageResource($this->whenLoaded('storage')),
            'source_type'=>$this->source_type,
            'supplier'=> new SupplierResource($this->whenLoaded('supplier')),
            'customer'=> new CustomerResource($this->whenLoaded('customer')),
            'purchase_invoice'=> new PurchaseInvoiceResource($this->whenLoaded('purchaseInvoice')),
            'imei'=>$this->imei,
            'country_code'=>$this->country_code,
            'battery_capacity'=>$this->battery_capacity,
            'import_price'=>$this->import_price,
            'import_date'=>$this->import_date? $this->import_date->toDateString(): null,
            'import_note'=>$this->import_note,
            'is_sold'=> (bool)$this->is_sold,
            'mobile_out'=> new MobileOutResource($this->whenLoaded('mobileOut')),
            'created_at'=>optional($this->created_at)->toISOString(),
        ];
    }
}
