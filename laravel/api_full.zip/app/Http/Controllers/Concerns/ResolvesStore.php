<?php
namespace App\Http\Controllers\Concerns;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\HttpException;

trait ResolvesStore
{
    protected function resolveStoreId(Request $request): int
    {
        $userId = $request->user()->id;

        $reqStoreId = $request->integer('store_id');
        if ($reqStoreId) {
            $exists = DB::table('user_in_store')
                ->where('user_id', $userId)
                ->where('store_id', $reqStoreId)
                ->exists();
            if (!$exists) {
                throw new HttpException(403, 'User không thuộc cửa hàng này');
            }
            return (int)$reqStoreId;
        }

        $storeId = DB::table('user_in_store')
            ->where('user_id', $userId)
            ->value('store_id');

        if (!$storeId) {
            throw new HttpException(422, 'User chưa thuộc cửa hàng nào');
        }
        return (int)$storeId;
    }
}
