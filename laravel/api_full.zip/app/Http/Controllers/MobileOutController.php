<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ResolvesStore;
use App\Models\MobileIn;
use App\Models\MobileOut;
use Illuminate\Http\Request;
use App\Http\Requests\{MobileOutStoreRequest, MobileOutUpdateRequest};
use App\Http\Resources\MobileOutResource;

class MobileOutController extends Controller
{
    use ResolvesStore;

    public function index(Request $r)
    {
        $q = MobileOut::with([
            'mobileIn:id,store_id,device_id,color_id,storage_id,imei,is_sold',
            'mobileIn.device:id,name',
            'mobileIn.color:id,vi_name',
            'mobileIn.storage:id,name,size_gb',
            'user:id,name',
            'customer:id,name,phone'
        ]);

        if ($s = trim((string)$r->input('q'))) {
            $q->whereHas('mobileIn', fn($w)=>$w->where('imei','like',"%{$s}%"));
        }
        if ($r->filled('store_id')) {
            $q->whereHas('mobileIn', fn($w)=>$w->where('store_id', $r->input('store_id')));
        }
        if ($f = $r->input('date_from')) $q->whereDate('export_date','>=',$f);
        if ($t = $r->input('date_to'))   $q->whereDate('export_date','<=',$t);

        $sortable = ['id','export_date','export_price'];
        $sortBy = in_array($r->input('sortBy'), $sortable, true) ? $r->input('sortBy') : 'id';
        $sortDir = strtolower($r->input('sortDir')) === 'asc' ? 'asc' : 'desc';
        $q->orderBy($sortBy, $sortDir);

        $perPage = max(1, min((int)$r->input('perPage', 15), 200));
        return MobileOutResource::collection($q->paginate($perPage));
    }

    public function store(MobileOutStoreRequest $r)
    {
        $userId = $r->user()->id;
        $storeId = $this->resolveStoreId($r);
        $data = $r->validated();

        $mob = MobileIn::findOrFail($data['mobile_in_id']);
        if ((int)$mob->store_id !== (int)$storeId) {
            return response()->json(['message'=>'Máy không thuộc cửa hàng này'], 403);
        }
        if ($mob->is_sold) {
            return response()->json(['message'=>'Máy đã bán trước đó'], 409);
        }

        $sale = MobileOut::create($data + ['user_id'=>$userId]);
        $mob->is_sold = 1; $mob->save();

        return (new MobileOutResource($sale->load(['mobileIn.device','user','customer'])))->response()->setStatusCode(201);
    }

    public function show($id)
    {
        $sale = MobileOut::with(['mobileIn.device','mobileIn.color','mobileIn.storage','user','customer'])->findOrFail($id);
        return new MobileOutResource($sale);
    }

    public function update(MobileOutUpdateRequest $r, $id)
    {
        $sale = MobileOut::findOrFail($id);
        $sale->update($r->validated());
        return new MobileOutResource($sale->load(['mobileIn.device','user','customer']));
    }

    public function destroy($id)
    {
        $sale = MobileOut::findOrFail($id);
        $mobId = $sale->mobile_in_id;
        $sale->delete();
        $mob = MobileIn::find($mobId);
        if ($mob) { $mob->is_sold = 0; $mob->save(); }
        return response()->json(['message'=>'Đã xoá hoá đơn bán và hoàn trạng thái máy về chưa bán.']);
    }
}
