<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ResolvesStore;
use App\Models\Service;
use Illuminate\Http\Request;
use App\Http\Requests\{ServiceStoreRequest, ServiceUpdateRequest};
use App\Http\Resources\ServiceResource;

class ServiceController extends Controller
{
    use ResolvesStore;

    public function index(Request $r)
    {
        $storeId = $this->resolveStoreId($r);

        $q = Service::with(['customer:id,name,phone','user:id,name'])
            ->where('store_id', $storeId);

        if ($s = trim((string)$r->input('q'))) {
            $q->where(fn($w)=>$w->where('name','like',"%{$s}%")->orWhere('note','like',"%{$s}%"));
        }
        if ($r->filled('customer_id')) $q->where('customer_id',$r->input('customer_id'));
        if ($f = $r->input('date_from')) $q->whereDate('created_at','>=',$f);
        if ($t = $r->input('date_to'))   $q->whereDate('created_at','<=',$t);

        $sortable = ['id','name','price','created_at'];
        $sortBy = in_array($r->input('sortBy'), $sortable, true) ? $r->input('sortBy') : 'id';
        $sortDir = strtolower($r->input('sortDir')) === 'asc' ? 'asc' : 'desc';
        $q->orderBy($sortBy, $sortDir);

        $perPage = max(1, min((int)$r->input('perPage', 15), 200));
        return ServiceResource::collection($q->paginate($perPage));
    }

    public function store(ServiceStoreRequest $r)
    {
        $storeId = $this->resolveStoreId($r);
        $userId = $r->user()->id;

        $data = $r->validated();
        $svc = Service::create($data + ['store_id'=>$storeId, 'user_id'=>$data['user_id'] ?? $userId]);
        return (new ServiceResource($svc->load(['customer:id,name,phone','user:id,name'])))->response()->setStatusCode(201);
    }

    public function show(Request $r, $id)
    {
        $storeId = $this->resolveStoreId($r);
        $svc = Service::with(['customer:id,name,phone','user:id,name'])->where('store_id',$storeId)->findOrFail($id);
        return new ServiceResource($svc);
    }

    public function update(ServiceUpdateRequest $r, $id)
    {
        $storeId = $this->resolveStoreId($r);
        $svc = Service::where('store_id',$storeId)->findOrFail($id);
        $svc->update($r->validated());
        return new ServiceResource($svc->load(['customer:id,name,phone','user:id,name']));
    }

    public function destroy(Request $r, $id)
    {
        $storeId = $this->resolveStoreId($r);
        $svc = Service::where('store_id',$storeId)->findOrFail($id);
        $svc->delete();
        return response()->json(['message'=>'Đã xoá.']);
    }
}
