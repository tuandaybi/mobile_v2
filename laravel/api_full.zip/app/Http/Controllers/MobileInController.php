<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ResolvesStore;
use App\Models\MobileIn;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Requests\{MobileInStoreRequest, MobileInUpdateRequest};
use App\Http\Resources\MobileInResource;

class MobileInController extends Controller
{
    use ResolvesStore;

    public function index(Request $r)
    {
        $q = MobileIn::select([
                'id','user_id','store_id','device_id','color_id','storage_id',
                'source_type','supplier_id','customer_id','purchase_invoice_id',
                'imei','country_code','battery_capacity','import_price','import_date',
                'import_note','is_sold','created_at'
            ])
            ->with([
                'user:id,name,email',
                'store:id,name,phone,address',
                'device:id,name',
                'color:id,vi_name,en_name',
                'storage:id,name,size_gb',
                'supplier:id,name',
                'customer:id,name,phone',
                'purchaseInvoice:id,invoice_no,invoice_date',
                'mobileOut:id,mobile_in_id,export_date,export_price'
            ]);

        if ($s = trim((string)$r->input('q'))) {
            $q->where(fn($w)=>$w->where('imei','like',"%{$s}%")
                ->orWhere('country_code','like',"%{$s}%")
                ->orWhere('import_note','like',"%{$s}%"));
        }

        foreach (['store_id','device_id','color_id','storage_id','supplier_id','customer_id','purchase_invoice_id'] as $col) {
            if ($v = $r->input($col)) { $q->where($col, $v); }
        }

        if ($r->filled('source_type')) $q->where('source_type', $r->input('source_type'));
        if ($r->filled('sold')) $q->where('is_sold', (int)$r->input('sold') ? 1 : 0);
        if ($f = $r->input('date_from')) $q->whereDate('import_date','>=',$f);
        if ($t = $r->input('date_to'))   $q->whereDate('import_date','<=',$t);

        $sortable = ['id','imei','import_date','import_price','is_sold'];
        $sortBy = in_array($r->input('sortBy'), $sortable, true) ? $r->input('sortBy') : 'id';
        $sortDir = strtolower($r->input('sortDir')) === 'asc' ? 'asc' : 'desc';
        $q->orderBy($sortBy, $sortDir);

        $perPage = max(1, min((int)$r->input('perPage', 15), 200));
        return MobileInResource::collection($q->paginate($perPage));
    }

    public function show($id)
    {
        $data = MobileIn::with([
            'user:id,name,email',
            'store:id,name,phone,address',
            'device:id,name',
            'color:id,vi_name,en_name',
            'storage:id,name,size_gb',
            'supplier:id,name,phone,email',
            'customer:id,name,phone',
            'purchaseInvoice:id,invoice_no,invoice_date,total',
            'mobileOut'
        ])->findOrFail($id);

        return new MobileInResource($data);
    }

    public function store(MobileInStoreRequest $r)
    {
        $userId  = $r->user()->id;
        $storeId = $this->resolveStoreId($r);
        $data = $r->validated();

        if ($data['source_type']==='supplier' && empty($data['supplier_id'])) {
            return response()->json(['message'=>'Thiếu supplier_id cho source_type=supplier'], 422);
        }
        if ($data['source_type']==='customer' && empty($data['customer_id'])) {
            return response()->json(['message'=>'Thiếu customer_id cho source_type=customer'], 422);
        }

        $mob = MobileIn::create($data + ['user_id'=>$userId,'store_id'=>$storeId])
                ->load(['device','color','storage','store','user','supplier','customer','purchaseInvoice']);

        return (new MobileInResource($mob))->response()->setStatusCode(201);
    }

    public function update(MobileInUpdateRequest $r, $id)
    {
        $mob = MobileIn::findOrFail($id);
        $data = $r->validated();

        $src = $data['source_type'] ?? $mob->source_type;
        if ($src==='supplier' && array_key_exists('supplier_id',$data) && empty($data['supplier_id'])) {
            return response()->json(['message'=>'Thiếu supplier_id cho source_type=supplier'], 422);
        }
        if ($src==='customer' && array_key_exists('customer_id',$data) && empty($data['customer_id'])) {
            return response()->json(['message'=>'Thiếu customer_id cho source_type=customer'], 422);
        }

        $mob->update($data);
        return new MobileInResource($mob->load(['device','color','storage','store','user','supplier','customer','purchaseInvoice']));
    }

    public function destroy($id)
    {
        $mob = MobileIn::with('mobileOut')->findOrFail($id);
        if ($mob->is_sold || $mob->mobileOut) {
            return response()->json(['message'=>'Không thể xoá vì máy đã được bán hoặc có bản ghi liên kết.'], 409);
        }
        $mob->delete();
        return response()->json(['message'=>'Đã xoá thành công.']);
    }

    public function toggleSold($id)
    {
        $mob = MobileIn::findOrFail($id);
        $mob->is_sold = !$mob->is_sold;
        $mob->save();
        return response()->json(['id'=>$mob->id,'is_sold'=>(bool)$mob->is_sold]);
    }
}
