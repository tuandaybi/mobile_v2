<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ServiceStoreRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'customer_id' => ['required','exists:customer,id'],
            'name'        => ['required','string','max:255'],
            'price'       => ['nullable','numeric','min:0'],
            'expense'     => ['nullable','numeric','min:0'],
            'user_id'     => ['nullable','exists:users,id'],
            'note'        => ['nullable','string'],
        ];
    }
}
