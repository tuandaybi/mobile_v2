<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class MobileInStoreRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        $storeId = (int)($this->input('store_id') ?: 0);
        return [
            'device_id'  => ['required','exists:devices,id'],
            'color_id'   => ['required','exists:colors,id'],
            'storage_id' => ['required','exists:storage,id'],
            'source_type'=> ['required', Rule::in(['supplier','customer','other'])],
            'supplier_id'=> ['nullable','exists:suppliers,id'],
            'customer_id'=> ['nullable','exists:customer,id'],
            'purchase_invoice_id' => ['nullable','exists:purchase_invoices,id'],
            'imei'       => ['required','string','max:15',
                Rule::unique('mobile_in','imei')->where(fn($q)=>$q->where('store_id',$storeId)->where('is_sold',0))],
            'country_code'     => ['nullable','string','max:10'],
            'battery_capacity' => ['nullable','integer','between:0,100'],
            'import_price'     => ['nullable','numeric','min:0'],
            'import_date'      => ['nullable','date'],
            'import_note'      => ['nullable','string'],
            'is_sold'          => ['nullable','boolean'],
        ];
    }
}
