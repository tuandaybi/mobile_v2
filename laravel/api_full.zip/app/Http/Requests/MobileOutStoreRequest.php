<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MobileOutStoreRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'mobile_in_id' => ['required','exists:mobile_in,id'],
            'customer_id'  => ['required','exists:customer,id'],
            'export_date'  => ['nullable','date'],
            'export_price' => ['required','numeric','min:0'],
            'expense'      => ['nullable','numeric','min:0'],
        ];
    }
}
