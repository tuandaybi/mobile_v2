<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class MobileInUpdateRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        $id = $this->route('id') ?? $this->route('mobile_in');
        $storeId = (int)($this->input('store_id') ?: 0);
        return [
            'store_id'  => ['sometimes','required','integer','exists:user_in_store,store_id'],
            'device_id'  => ['sometimes','required','exists:devices,id'],
            'color_id'   => ['sometimes','required','exists:colors,id'],
            'storage_id' => ['sometimes','required','exists:storage,id'],
            'source_type'=> ['sometimes','required', Rule::in(['supplier','customer','other'])],
            'supplier_id'=> ['sometimes','nullable','exists:suppliers,id'],
            'customer_id'=> ['sometimes','nullable','exists:customer,id'],
            'purchase_invoice_id' => ['sometimes','nullable','exists:purchase_invoices,id'],
            'imei'       => ['sometimes','required','string','max:15',
                Rule::unique('mobile_in','imei')->ignore($id)
                    ->where(fn($q)=>$q->where('store_id',$storeId)->where('is_sold',0))],
            'country_code'     => ['sometimes','nullable','string','max:10'],
            'battery_capacity' => ['sometimes','nullable','integer','between:0,100'],
            'import_price'     => ['sometimes','nullable','numeric','min:0'],
            'import_date'      => ['sometimes','nullable','date'],
            'import_note'      => ['sometimes','nullable','string'],
            'is_sold'          => ['sometimes','boolean'],
        ];
    }
}
