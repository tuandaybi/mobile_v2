<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    MobileInController, MobileOutController,
    SupplierController, PurchaseInvoiceController,
    ColorController, DeviceStorageController, CustomerController, ServiceController
};

Route::middleware('auth:sanctum')->group(function () {
    // Mobile In
    Route::get('/mobile-in', [MobileInController::class,'index']);
    Route::get('/mobile-in/{id}', [MobileInController::class,'show']);
    Route::post('/mobile-in', [MobileInController::class,'store']);
    Route::match(['put','patch'],'/mobile-in/{id}', [MobileInController::class,'update']);
    Route::delete('/mobile-in/{id}', [MobileInController::class,'destroy']);
    Route::patch('/mobile-in/{id}/toggle-sold', [MobileInController::class,'toggleSold']);

    // Mobile Out
    Route::get('/mobile-out', [MobileOutController::class,'index']);
    Route::get('/mobile-out/{id}', [MobileOutController::class,'show']);
    Route::post('/mobile-out', [MobileOutController::class,'store']);
    Route::match(['put','patch'],'/mobile-out/{id}', [MobileOutController::class,'update']);
    Route::delete('/mobile-out/{id}', [MobileOutController::class,'destroy']);

    // Suppliers
    Route::apiResource('suppliers', SupplierController::class)->except(['create','edit']);

    // Purchase Invoices
    Route::apiResource('purchase-invoices', PurchaseInvoiceController::class)->except(['create','edit']);

    // Master data
    Route::apiResource('colors', ColorController::class)->except(['create','edit']);
    Route::apiResource('storage', DeviceStorageController::class)->except(['create','edit']);
    Route::apiResource('customers', CustomerController::class)->except(['create','edit']);
    Route::apiResource('services', ServiceController::class)->except(['create','edit']);
});
